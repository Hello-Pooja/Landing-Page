An idea for the landing page of a website for fashion apparel made using Bootstrap and CSS
 
https://user-images.githubusercontent.com/72339853/116185603-8d47c000-a73f-11eb-8e4b-67aa325a6b2c.mp4
