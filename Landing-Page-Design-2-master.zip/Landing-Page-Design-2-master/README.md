Netflix clone with new cursor effect 

https://user-images.githubusercontent.com/72339853/116185405-288c6580-a73f-11eb-8e93-5eeb4b56ce33.mp4
