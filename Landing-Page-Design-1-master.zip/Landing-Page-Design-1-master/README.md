Starbucks landing page design made using Bootstrap and CSS

https://user-images.githubusercontent.com/72339853/116184832-21b12300-a73e-11eb-87e7-9d388fd8c8f8.mp4
